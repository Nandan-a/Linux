#!/bin/bash

name="Nandan"
if [[ $name == "Nandan" ]]
then
    echo "Nandan found in the list"
fi

name='Ritesh'
if [[ $name == "Ritesh" ]]
then
    echo "$name found in the list"
fi

prn=0011
if [[ prn -eq 0011 ]] 
then
    echo "The  name is Ritesh in PGDIOT class"
fi