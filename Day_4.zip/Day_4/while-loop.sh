#!/bin/bash

while :
do 
echo "I am inside while loop"
sleep 2
echo "I have just wakeup after 10 seconds"
done

