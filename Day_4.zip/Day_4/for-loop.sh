#!/bin/bash

for (( count=0; count<5; count++ ))
do 
	echo "Hello"
done
