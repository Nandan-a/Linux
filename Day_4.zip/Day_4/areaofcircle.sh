#!/bin/bash

read -p "Enter radius of circle" r
echo "3.14 * $r * $r" | bc
 
