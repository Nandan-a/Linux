#!/bin/bash

for i in {0..10..2}
do 
	echo $i
done
