#!/bin/bash

file=/home/ritesh/DBMS/
loc=/home/ritesh/Desktop/6oct.txt
mv $file $loc
