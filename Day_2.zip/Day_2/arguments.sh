#!/bin/bash



file=/home/ritesh/DBMS/Abc.csv
loc=/home/ritesh/Desktop/
cp $file $loc
echo $$
echo $#
echo $*
echo $?