#!/bin/bash
cd /home/ritesh/
gcc area.c -o area.out
