#!/bin/bash



echo "the value of \$1 = $1"
echo "the value of \$20 = $20"
echo "the value of \${10} = ${10}"
echo "the value of \$0 = $0"
