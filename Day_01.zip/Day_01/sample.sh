#!/bin/bash

read -p  'Enter your user name : ' firstname
read -sp 'password : ' password
echo
echo Thankyou $firstname for Providing the details
echo your New password is worst : $password


