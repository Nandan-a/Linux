#!/bin/bash

read -p "firstname : " fn

read -p "lastname : " ln
name=$fn" "$ln
echo $name